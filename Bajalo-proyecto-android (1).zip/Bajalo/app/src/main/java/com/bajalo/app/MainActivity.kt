package com.bajalo.app

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.io.IOException

private val Brand = Color(0xFFE53935)
private val Bg = Color(0xFFF5F5F5)

// ---------- Datos ----------

class DownloadItem(val id: Int, initialTitle: String, val audio: Boolean) {
    var title by mutableStateOf(initialTitle)
    var progress by mutableFloatStateOf(0f)
    var status by mutableStateOf("En cola")
    var done by mutableStateOf(false)
    var failed by mutableStateOf(false)
    var log by mutableStateOf("")
    @Volatile var cancelled = false
    @Volatile var pid = ""
}

class Pending(val url: String, val title: String?)

object Store {
    val downloads = mutableStateListOf<DownloadItem>()
    var pending by mutableStateOf<Pending?>(null)
    var engine by mutableStateOf("Iniciando motor…")
    var nextId = 1
}

class Site(val name: String, val tag: String, val color: Color, val url: String)

private val sites = listOf(
    Site("YouTube", "YT", Color(0xFFE53935), "https://m.youtube.com"),
    Site("Facebook", "f", Color(0xFF1877F2), "https://m.facebook.com"),
    Site("Instagram", "IG", Color(0xFFC13584), "https://www.instagram.com"),
    Site("TikTok", "TT", Color(0xFF212121), "https://www.tiktok.com"),
    Site("X", "X", Color(0xFF424242), "https://x.com"),
    Site("Vimeo", "V", Color(0xFF1AB7EA), "https://vimeo.com"),
    Site("SoundCloud", "SC", Color(0xFFFF5500), "https://m.soundcloud.com"),
    Site("Dailymotion", "dm", Color(0xFF0066DC), "https://www.dailymotion.com"),
)

// ---------- Motor de descarga (yt-dlp + FFmpeg) ----------

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            try {
                Store.engine = "Iniciando motor…"
                YoutubeDL.init(this)
                FFmpeg.init(this)
                ready.complete(Unit)
                Store.engine = "Motor listo · actualizando yt-dlp…"
                try { YoutubeDL.updateYoutubeDL(this) } catch (e: Throwable) { }
                Store.engine = "Motor listo · yt-dlp " + ytdlpVersion(this)
            } catch (e: Throwable) {
                ready.completeExceptionally(e)
                Store.engine = "Error del motor: " + (e.message ?: e.toString()).take(100)
            }
        }.start()
    }

    companion object {
        val ready = CompletableDeferred<Unit>()
    }
}

private fun ytdlpVersion(ctx: Context): String =
    try { YoutubeDL.version(ctx) ?: "" } catch (e: Throwable) { "" }

private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

private fun buildRequest(url: String, dir: File, audio: Boolean, fast: Boolean): YoutubeDLRequest {
    val req = YoutubeDLRequest(url)
    req.addOption("--no-playlist")
    req.addOption("--socket-timeout", 30)
    req.addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
    // Método rápido para YouTube: el cliente "visionos" no necesita resolver el
    // reto de JavaScript (que en celular tarda mucho). Si falla, se reintenta sin esto.
    if (fast) req.addOption("--extractor-args", "youtube:player_client=visionos")
    if (audio) {
        req.addOption("-f", "ba/b")
        req.addOption("-x")
        req.addOption("--audio-format", "mp3")
        req.addOption("--audio-quality", "0")
    } else {
        req.addOption("-f", "bv*+ba/b")
        req.addOption("-S", "res:720,ext:mp4:m4a")
        req.addOption("--merge-output-format", "mp4")
    }
    return req
}

private fun stage(l: String): String? = when {
    l.startsWith("ERROR") -> "Error: " + l.removePrefix("ERROR:").trim().take(100)
    "Solving JS" in l -> "Resolviendo la protección de YouTube (puede tardar)…"
    l.startsWith("[youtube]") -> "Analizando video…"
    l.startsWith("[info]") -> "Preparando descarga…"
    l.startsWith("[ExtractAudio]") -> "Convirtiendo a MP3…"
    l.startsWith("[Merger]") || l.startsWith("[VideoRemuxer]") -> "Uniendo audio y video…"
    l.startsWith("[download]") -> "Descargando…"
    else -> null
}

private fun onLine(item: DownloadItem, p: Float, raw: String) {
    val l = raw.trim()
    if (l.isEmpty()) return
    item.log = (item.log + "\n" + l).takeLast(4000)
    if (l.startsWith("[download]") && "%" in l && p in 0f..100f) {
        item.progress = p / 100f
        item.status = "Descargando… ${p.toInt()}%"
        return
    }
    stage(l)?.let { item.status = it }
}

fun startDownload(ctx: Context, url: String, title: String, audio: Boolean) {
    val item = DownloadItem(Store.nextId++, title, audio)
    Store.downloads.add(item)
    appScope.launch {
        try {
            item.status = "Iniciando motor…"
            withTimeoutOrNull(120_000) { App.ready.await() }
                ?: throw IOException("El motor tardó demasiado en iniciar")
            val dir = File(ctx.getExternalFilesDir(null), "dl/${item.id}").apply { mkdirs() }
            val attempts = if ("youtu" in url) listOf(true, false) else listOf(false)
            var ok = false
            var failure: String? = null
            for ((i, fast) in attempts.withIndex()) {
                if (item.cancelled) throw YoutubeDL.CanceledException()
                dir.listFiles()?.forEach { it.delete() }
                item.progress = 0f
                item.pid = "dl${item.id}-$i"
                item.status = if (i > 0) "Reintentando con el método completo (más lento)…" else "Analizando video…"
                if (i > 0) item.log += "\n--- reintento ---"
                val req = buildRequest(url, dir, audio, fast)
                try {
                    YoutubeDL.execute(req, item.pid, true) { p, _, line -> onLine(item, p, line) }
                    ok = true
                    break
                } catch (e: YoutubeDL.CanceledException) {
                    throw e
                } catch (e: Exception) {
                    failure = item.log.lines().lastOrNull { it.startsWith("ERROR") }
                        ?: e.message ?: "falló la descarga"
                }
            }
            if (!ok) throw IOException(failure ?: "falló la descarga")
            item.status = "Guardando…"
            val file = dir.listFiles()
                ?.filter { it.isFile && it.extension !in listOf("part", "ytdl", "temp") }
                ?.maxByOrNull { it.length() }
                ?: throw IOException("No se encontró el archivo descargado")
            item.title = file.nameWithoutExtension
            saveToPublic(ctx, file, audio)
            item.progress = 1f
            item.status = if (audio) "Listo · guardado en Música/Bajalo" else "Listo · guardado en Películas/Bajalo"
            item.done = true
        } catch (e: YoutubeDL.CanceledException) {
            item.failed = true
            item.status = "Cancelado"
        } catch (e: Throwable) {
            item.failed = true
            item.status = "Error: " + (e.message ?: e.toString()).take(140)
        }
    }
}

fun saveToPublic(ctx: Context, file: File, audio: Boolean) {
    val mime = when (file.extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "opus", "ogg" -> "audio/ogg"
        "mkv" -> "video/x-matroska"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        else -> if (audio) "audio/mpeg" else "video/mp4"
    }
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/Bajalo" else "Movies/Bajalo")
    }
    val table = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val uri = ctx.contentResolver.insert(table, values) ?: throw IOException("No se pudo guardar el archivo")
    val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("No se pudo escribir el archivo")
    out.use { o -> file.inputStream().use { it.copyTo(o) } }
    file.delete()
}

private fun ytId(url: String): String? {
    val u = Uri.parse(url)
    val host = u.host ?: return null
    return when {
        host.contains("youtu.be") -> u.lastPathSegment
        host.contains("youtube.com") -> u.getQueryParameter("v")
        else -> null
    }
}

// ---------- Pantallas ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#C62828")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        handle(intent)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Brand)) { BajaloApp() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    // Permite "Compartir" un enlace desde otra app hacia Bájalo.
    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            Regex("https?://\\S+").find(text)?.value?.let { Store.pending = Pending(it, null) }
        }
    }
}

@Composable
fun BajaloApp() {
    var browserUrl by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        val b = browserUrl
        if (b == null) Home(onSite = { browserUrl = it }) else Browser(b, onClose = { browserUrl = null })
        val p = Store.pending
        if (p != null) {
            FormatDialog(p, onDismiss = { Store.pending = null }) { audio ->
                Store.pending = null
                browserUrl = null
                startDownload(ctx.applicationContext, p.url, p.title ?: p.url, audio)
            }
        }
    }
}

@Composable
fun Home(onSite: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    fun go() {
        val t = text.trim()
        if (t.isEmpty()) return
        if (t.startsWith("http")) Store.pending = Pending(t, null)
        else onSite("https://m.youtube.com/results?search_query=" + Uri.encode(t))
    }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxWidth().background(Brand).padding(12.dp)) {
            Text("Bájalo", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            TextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Busca o pega un enlace") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = { IconButton(onClick = { go() }) { Icon(Icons.Default.Search, "Buscar") } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
            )
            Text(
                Store.engine,
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(sites.chunked(4)) { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { s -> SiteIcon(s, Modifier.weight(1f)) { onSite(s.url) } }
                }
            }
            item {
                Text("Descargas", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
            if (Store.downloads.isEmpty()) {
                item { Text("Aquí aparecerán tus descargas.", color = Color.Gray) }
            }
            items(Store.downloads.reversed()) { DownloadRow(it) }
        }
    }
}

@Composable
fun SiteIcon(s: Site, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(52.dp).background(s.color, CircleShape), contentAlignment = Alignment.Center) {
            Text(s.tag, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(s.name, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun DownloadRow(d: DownloadItem) {
    val ctx = LocalContext.current
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(
                (if (d.audio) "♪ " else "▶ ") + d.title,
                maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(6.dp))
            if (!d.done && !d.failed) {
                if (d.progress <= 0f) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Brand)
                } else {
                    LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.fillMaxWidth(), color = Brand)
                }
            }
            Text(
                d.status, fontSize = 12.sp,
                color = if (d.failed) Color(0xFFB71C1C) else Color.Gray,
                modifier = Modifier.padding(top = 4.dp),
            )
            Row {
                if (!d.done && !d.failed) {
                    TextButton(onClick = {
                        d.cancelled = true
                        try { YoutubeDL.destroyProcessById(d.pid) } catch (e: Throwable) { }
                        d.failed = true
                        d.status = "Cancelado"
                    }) { Text("Cancelar") }
                }
                if (d.log.isNotEmpty() && !d.done) {
                    TextButton(onClick = {
                        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("registro", d.title + "\n" + d.status + "\n" + d.log))
                        Toast.makeText(ctx, "Registro copiado", Toast.LENGTH_SHORT).show()
                    }) { Text("Copiar registro") }
                }
            }
        }
    }
}

@Composable
fun Browser(startUrl: String, onClose: () -> Unit) {
    var current by remember { mutableStateOf(startUrl) }
    var pageTitle by remember { mutableStateOf("") }
    var web by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Brand).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
                Text(current, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            }
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                if (url != null) current = url
                            }
                        }
                        webChromeClient = object : WebChromeClient() {
                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                if (title != null) pageTitle = title
                            }
                        }
                        loadUrl(startUrl)
                    }
                },
                update = { web = it },
            )
        }
        FloatingActionButton(
            onClick = {
                val t = pageTitle.removeSuffix(" - YouTube").trim()
                Store.pending = Pending(current, if (t.isEmpty()) null else t)
            },
            containerColor = Brand,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) { Icon(Icons.Default.Download, "Descargar") }
    }
}

// Las opciones salen al instante: ya no se analiza el video antes de mostrarlas.
@Composable
fun FormatDialog(p: Pending, onDismiss: () -> Unit, onPick: (Boolean) -> Unit) {
    val id = ytId(p.url)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Descargar") },
        text = {
            Column {
                if (id != null) {
                    AsyncImage(
                        model = "https://i.ytimg.com/vi/$id/hqdefault.jpg",
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)),
                    )
                }
                Text(p.title ?: p.url, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                Text(
                    "Al empezar puede tardar un poco mientras analiza el video.",
                    color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onPick(false) }, colors = ButtonDefaults.buttonColors(containerColor = Brand)) { Text("Video MP4") }
                Button(onClick = { onPick(true) }, colors = ButtonDefaults.buttonColors(containerColor = Brand)) { Text("Música MP3") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
