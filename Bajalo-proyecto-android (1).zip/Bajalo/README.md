# Bájalo — descargador de videos y música (estilo SnapTube)

App Android (Kotlin + Jetpack Compose) con el motor yt-dlp + FFmpeg (librería de código abierto youtubedl-android).

**Qué hace:** pantalla de inicio roja con barra de búsqueda/enlace y atajos a sitios, navegador integrado con botón
de descarga, o pega/comparte un enlace → eliges **Video MP4** (hasta 720p) o **Música MP3**.
Se guarda en `Películas/Bajalo` y `Música/Bajalo`. Requiere Android 10 o superior.

> Esta versión no se pudo compilar ni probar al generarla: puede salir algún error en la primera compilación.
> Copia el error y se corrige.

## Opción A — Sin instalar nada: GitHub compila el APK
1. Crea una cuenta gratis en github.com y un repositorio nuevo (privado está bien).
2. Sube TODO el contenido de esta carpeta (incluida la carpeta oculta `.github`).
   Con git: `git init && git add . && git commit -m app && git branch -M main && git remote add origin <URL> && git push -u origin main`
3. Entra a la pestaña **Actions** → **Compilar APK** (tarda 5–10 min la primera vez).
4. Abajo, en **Artifacts**, descarga **Bajalo-APK**, descomprime y pasa `app-debug.apk` al teléfono.
5. Ábrelo en el teléfono y permite "instalar apps de orígenes desconocidos".

## Opción B — Android Studio
1. Instala Android Studio, **Open** → esta carpeta, espera el *Gradle sync*.
2. Conecta el teléfono con depuración USB → botón **Run**.
   O **Build → Build APK(s)** y busca `app/build/outputs/apk/debug/app-debug.apk`.

## Actualizar la app (versión 1.1)
1. En el repositorio: **Add file → Upload files**, sube el ZIP nuevo con el MISMO nombre y **Commit changes**.
2. Espera el ✅ en **Actions** y baja el APK desde **Releases**.
3. Desinstala la versión anterior antes de instalar (solo esta vez; desde ahora las versiones se instalan encima).

## Notas
- Las opciones (Video MP4 / Música MP3) salen al instante. El análisis del video ocurre al descargar y se ve en la tarjeta de la descarga.
- Para YouTube se intenta primero un método rápido; si falla, reintenta con el método completo (más lento).
- Si una descarga falla o se queda trabada, usa **Copiar registro** y pégalo en el chat.
- Deja la app abierta mientras descarga (esta versión no tiene servicio en segundo plano).
- Si un sitio deja de funcionar, abre la app con internet: actualiza yt-dlp sola en cada arranque.
- Úsala solo con contenido que tengas derecho a descargar (propio, Creative Commons, dominio público).
