package com.bajalo.app

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

private val Brand = Color(0xFFE53935)
private val Bg = Color(0xFFF5F5F5)

// ---------- Datos ----------

class DownloadItem(val id: Int, val title: String, val audio: Boolean) {
    var progress by mutableFloatStateOf(0f)
    var status by mutableStateOf("En cola")
    var done by mutableStateOf(false)
    var failed by mutableStateOf(false)
}

object Store {
    val downloads = mutableStateListOf<DownloadItem>()
    var pending by mutableStateOf<String?>(null)
    var nextId = 1
}

class Site(val name: String, val tag: String, val color: Color, val url: String)

private val sites = listOf(
    Site("YouTube", "YT", Color(0xFFE53935), "https://m.youtube.com"),
    Site("Facebook", "f", Color(0xFF1877F2), "https://m.facebook.com"),
    Site("Instagram", "IG", Color(0xFFC13584), "https://www.instagram.com"),
    Site("TikTok", "TT", Color(0xFF212121), "https://www.tiktok.com"),
    Site("X", "X", Color(0xFF424242), "https://x.com"),
    Site("Vimeo", "V", Color(0xFF1AB7EA), "https://vimeo.com"),
    Site("SoundCloud", "SC", Color(0xFFFF5500), "https://m.soundcloud.com"),
    Site("Dailymotion", "dm", Color(0xFF0066DC), "https://www.dailymotion.com"),
)

// ---------- Motor de descarga (yt-dlp + FFmpeg) ----------

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread {
            try {
                YoutubeDL.init(this)
                FFmpeg.init(this)
                ready.complete(Unit)
                // Los sitios cambian seguido: se actualiza yt-dlp en cada arranque.
                try { YoutubeDL.updateYoutubeDL(this) } catch (e: Exception) { }
            } catch (e: Exception) {
                ready.completeExceptionally(e)
            }
        }.start()
    }

    companion object {
        val ready = CompletableDeferred<Unit>()
    }
}

private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

fun startDownload(ctx: Context, url: String, title: String, audio: Boolean) {
    val item = DownloadItem(Store.nextId++, title, audio)
    Store.downloads.add(item)
    appScope.launch {
        try {
            App.ready.await()
            val dir = File(ctx.getExternalFilesDir(null), "dl/${item.id}").apply { mkdirs() }
            val req = YoutubeDLRequest(url)
            req.addOption("--no-playlist")
            req.addOption("-o", "${dir.absolutePath}/%(title).80s.%(ext)s")
            if (audio) {
                req.addOption("-x")
                req.addOption("--audio-format", "mp3")
                req.addOption("--audio-quality", "0")
            } else {
                req.addOption("-f", "bv*[height<=720]+ba/b[height<=720]/b")
                req.addOption("--merge-output-format", "mp4")
            }
            item.status = "Descargando…"
            YoutubeDL.execute(req, "dl${item.id}") { p, _, _ ->
                item.progress = (p / 100f).coerceIn(0f, 1f)
                item.status = "Descargando… ${(item.progress * 100).toInt()}%"
            }
            item.status = "Guardando…"
            val file = dir.listFiles()
                ?.filter { it.isFile && it.extension !in listOf("part", "ytdl", "temp") }
                ?.maxByOrNull { it.length() }
                ?: throw IOException("No se encontró el archivo descargado")
            saveToPublic(ctx, file, audio)
            item.progress = 1f
            item.status = if (audio) "Listo · guardado en Música/Bajalo" else "Listo · guardado en Películas/Bajalo"
            item.done = true
        } catch (e: Exception) {
            item.failed = true
            item.status = "Error: " + (e.message ?: "falló la descarga").take(140)
        }
    }
}

fun saveToPublic(ctx: Context, file: File, audio: Boolean) {
    val mime = when (file.extension.lowercase()) {
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "opus", "ogg" -> "audio/ogg"
        "mkv" -> "video/x-matroska"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        else -> if (audio) "audio/mpeg" else "video/mp4"
    }
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, if (audio) "Music/Bajalo" else "Movies/Bajalo")
    }
    val table = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val uri = ctx.contentResolver.insert(table, values) ?: throw IOException("No se pudo guardar el archivo")
    val out = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("No se pudo escribir el archivo")
    out.use { o -> file.inputStream().use { it.copyTo(o) } }
    file.delete()
}

// ---------- Pantallas ----------

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.parseColor("#C62828")
        handle(intent)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Brand)) { BajaloApp() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    // Permite "Compartir" un enlace desde otra app hacia Bájalo.
    private fun handle(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            Regex("https?://\\S+").find(text)?.value?.let { Store.pending = it }
        }
    }
}

@Composable
fun BajaloApp() {
    var browserUrl by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        val b = browserUrl
        if (b == null) Home(onSite = { browserUrl = it }) else Browser(b, onClose = { browserUrl = null })
        val p = Store.pending
        if (p != null) {
            FormatDialog(p, onDismiss = { Store.pending = null }) { title, audio ->
                Store.pending = null
                browserUrl = null
                startDownload(ctx.applicationContext, p, title, audio)
            }
        }
    }
}

@Composable
fun Home(onSite: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    fun go() {
        val t = text.trim()
        if (t.isEmpty()) return
        if (t.startsWith("http")) Store.pending = t
        else onSite("https://m.youtube.com/results?search_query=" + Uri.encode(t))
    }
    Column(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxWidth().background(Brand).padding(12.dp)) {
            Text("Bájalo", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            TextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("Busca o pega un enlace") },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth(),
                trailingIcon = { IconButton(onClick = { go() }) { Icon(Icons.Default.Search, "Buscar") } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
            )
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(sites.chunked(4)) { row ->
                Row(Modifier.fillMaxWidth()) {
                    row.forEach { s -> SiteIcon(s, Modifier.weight(1f)) { onSite(s.url) } }
                }
            }
            item {
                Text("Descargas", fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
            if (Store.downloads.isEmpty()) {
                item { Text("Aquí aparecerán tus descargas.", color = Color.Gray) }
            }
            items(Store.downloads.reversed()) { DownloadRow(it) }
        }
    }
}

@Composable
fun SiteIcon(s: Site, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(52.dp).background(s.color, CircleShape), contentAlignment = Alignment.Center) {
            Text(s.tag, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(s.name, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun DownloadRow(d: DownloadItem) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(
                (if (d.audio) "♪ " else "▶ ") + d.title,
                maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(6.dp))
            if (!d.done && !d.failed) {
                LinearProgressIndicator(progress = { d.progress }, modifier = Modifier.fillMaxWidth(), color = Brand)
            }
            Text(
                d.status, fontSize = 12.sp,
                color = if (d.failed) Color(0xFFB71C1C) else Color.Gray,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

@Composable
fun Browser(startUrl: String, onClose: () -> Unit) {
    var current by remember { mutableStateOf(startUrl) }
    var web by remember { mutableStateOf<WebView?>(null) }
    BackHandler {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().background(Brand).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Volver", tint = Color.White) }
                Text(current, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            }
            AndroidView(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        webViewClient = object : WebViewClient() {
                            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                                if (url != null) current = url
                            }
                        }
                        loadUrl(startUrl)
                    }
                },
                update = { web = it },
            )
        }
        FloatingActionButton(
            onClick = { Store.pending = current },
            containerColor = Brand,
            contentColor = Color.White,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
        ) { Icon(Icons.Default.Download, "Descargar") }
    }
}

@Composable
fun FormatDialog(url: String, onDismiss: () -> Unit, onPick: (String, Boolean) -> Unit) {
    var title by remember(url) { mutableStateOf<String?>(null) }
    var thumb by remember(url) { mutableStateOf<String?>(null) }
    var secs by remember(url) { mutableIntStateOf(0) }
    var err by remember(url) { mutableStateOf<String?>(null) }

    LaunchedEffect(url) {
        try {
            App.ready.await()
            val req = YoutubeDLRequest(url)
            req.addOption("--no-playlist")
            val info = withContext(Dispatchers.IO) { YoutubeDL.getInfo(req) }
            title = info.title ?: "Sin título"
            thumb = info.thumbnail
            secs = info.duration
        } catch (ex: Exception) {
            err = ex.message?.take(160) ?: "No se pudo leer el enlace"
        }
    }

    val titleVal = title
    val errVal = err
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Descargar") },
        text = {
            Column {
                when {
                    errVal != null -> Text(errVal, color = Color(0xFFB71C1C))
                    titleVal == null -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp), color = Brand, strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Analizando enlace…")
                    }
                    else -> {
                        thumb?.let {
                            AsyncImage(
                                model = it, contentDescription = null, contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(8.dp)),
                            )
                        }
                        Text(titleVal, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                        if (secs > 0) Text("%d:%02d".format(secs / 60, secs % 60), color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = {
            if (titleVal != null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onPick(titleVal, false) }, colors = ButtonDefaults.buttonColors(containerColor = Brand)) { Text("Video MP4") }
                    Button(onClick = { onPick(titleVal, true) }, colors = ButtonDefaults.buttonColors(containerColor = Brand)) { Text("Música MP3") }
                }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
